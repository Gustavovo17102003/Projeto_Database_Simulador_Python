import tkinter as tk
import banco_de_usuarios
import interface_do_banco
from tkinter import messagebox

class login:
    #construtor
    def __init__(self):
        self.janela = tk.Tk()
        self.banco_de_usuarios = banco_de_usuarios.banco_usuarios()
        

    #funcao da interface 
    def Janela(self):
        try:
            #funcao do botao criar usuario
            def Botao_criar_usuario():
                try:
                    usuario = self.campo_usuario.get()
                    senha = self.campo_senha.get()
                    if usuario == "" or senha == "":
                        messagebox.showinfo("Aviso", "Campo vazio!")
                    else:
                        usuario = self.campo_usuario.get()
                        senha = self.campo_senha.get()
                        self.banco_de_usuarios.inserir_usuario(usuario)
                        self.banco_de_usuarios.inserir_senha(senha)
                        self.banco_de_usuarios.salvar_usuarios()
                except ValueError:
                    messagebox.showinfo("Aviso", "Erro na função Botao_criar_usuarios!")
       
            
            #funcao do botao entrar
            def Botao_Entrar():
                usuario = self.campo_usuario.get()
                senha = self.campo_senha.get()

                if usuario == "" or senha == "":
                    messagebox.showinfo("Aviso", "Campo vazio!")
                else:
                    if self.banco_de_usuarios.verificar_registro(usuario,senha) == True:
                        interface_banco = interface_do_banco.interface_banco()
                        self.janela.destroy()
                        interface_banco.Janela()
                    else:
                        messagebox.showinfo("Aviso", "Usuário não encontrado!")

            self.janela.title("Janela de Login")
            self.janela.configure(background="bisque2")

            self.label_usuario = tk.Label(self.janela,text="Usuário")
            self.label_usuario.configure(background="bisque2")
            self.label_usuario.grid(row=0,column=0,padx=20,pady=20)

            self.campo_usuario = tk.Entry(self.janela)
            self.campo_usuario.grid(row=0,column=1,padx=20,pady=20)

            self.label_senha = tk.Label(self.janela,text="Senha")
            self.label_senha.configure(background="bisque2")
            self.label_senha.grid(row=1,column=0,padx=20,pady=20)

            self.campo_senha= tk.Entry(self.janela,show="*")
            self.campo_senha.grid(row=1,column=1,padx=20,pady=20)

            self.botao_entrar = tk.Button(self.janela,text="Entrar",command=Botao_Entrar)
            self.botao_entrar.config(background="SpringGreen2")
            self.botao_entrar.grid(row=2,column=0,padx=20,pady=20)

            self.botao_criar_usuario = tk.Button(self.janela,text="Criar Usuário",command=Botao_criar_usuario)
            self.botao_criar_usuario.config(background="SpringGreen2")
            self.botao_criar_usuario.grid(row=2,column=1,padx=20,pady=20)

            self.janela.mainloop()

        except ValueError:
            messagebox.showinfo("Aviso", "Erro na função Janela!")