from tkinter import messagebox
import json
import os

class banco_usuarios:
    def __init__(self) :
        self.database_usuarios  = []
        self.database_senhas  = []
        self.carregar_dados()
        

    #funcao para inserir senhas no banco
    def inserir_senha(self,senha):
        try:
            self.database_senhas.append(senha)
            messagebox.showinfo("Aviso", "Usuário inserido com sucesso!")
        except ValueError:
            messagebox.showinfo("Aviso", "Erro ao inserir o usuário!")

        

    #funcao para inserir usuarios no banco
    def inserir_usuario(self,usuario):
        try:
            self.database_usuarios.append(usuario)
            self.salvar_usuarios()
        except ValueError:
            messagebox.showinfo("Aviso", "Erro ao inserir a senha!")


    #funcao para salvar os dados
    def salvar_usuarios(self, nome_arquivo="dados.json"):
        try:
            with open(nome_arquivo, 'w') as arquivo:
                dados = {"usuarios": self.database_usuarios, "senhas": self.database_senhas}
                json.dump(dados, arquivo)
        except ValueError:
            messagebox.showinfo("Aviso", "Erro ao salvar os usuários no arquivo")

    #funcao para carregar os dados do arquivo
    def carregar_dados(self, nome_arquivo="dados.json"):
        try:
            with open(nome_arquivo, 'r') as arquivo:
                dados = json.load(arquivo)
                self.database_usuarios = dados.get("usuarios", [])
                self.database_senhas = dados.get("senhas", [])
        except FileNotFoundError:
            pass


    #funcao para verificar se o usuario esta no banco
    def verificar_registro(self,usuario,senha):
        try:
            if usuario in self.database_usuarios and senha in self.database_senhas:
                return True
            else:
                return False
        except ValueError:
            messagebox.showinfo("Aviso", "Erro ao verificar registros!")
        

    