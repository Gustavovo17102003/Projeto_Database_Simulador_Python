from tkinter import messagebox
import matplotlib.pyplot as plt
# Classe para guardar as informações
class BancoInformacoes:
    # Construtor
    def __init__(self):
        self.dado = []
        self.text = []

    # Função para inserir dados
    def inserir(self, dado):
            try:
                self.dado.append(dado)
                messagebox.showinfo("Aviso", "Dado inserido!")
            except ValueError:
                messagebox.showinfo("Aviso", "Erro ao inserir o dado!")
       
       

    # Função para remover dados
    def apagar(self, dado):
        try:
            self.dado.remove(dado)
        except ValueError:
            messagebox.showinfo("Aviso", "Erro ao apagar o dado!")

    # Função para retornar o banco em forma de tabela
    def tabela(self):
        try:
            self.text.clear()
            self.text.append("Chave                             Dado")
            for index, dado in enumerate(self.dado):
                self.text.append(f"{index:<6}                          {dado:>6}")
            separador = "\n"
            return separador.join(self.text)
        except ValueError:
            messagebox.showinfo("Aviso", "Erro ao criar a tabela de informações!")
    
    def Ocorrencias(self,dado):
        try:
            numero = 0
            for i in  self.dado:
                if i ==  dado:
                    numero+=1
            messagebox.showinfo("Ocorrências", f"Número de ocorrências: {numero}")
            return str(numero)
        except ValueError:
            messagebox.showinfo("Aviso", "Erro ao calcular o número de ocorrências!")

    def grafico_de_pizza(self):
        try:
            unique_values, counts = zip(*[(value, self.dado.count(value)) for value in set(self.dado)])
            plt.pie(counts, labels=unique_values, autopct='%1.1f%%', startangle=140)
            plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
            plt.title('Gráfico de Pizza')
            plt.show()
        except Exception as e:
            messagebox.showinfo("Aviso", f"Erro ao criar o gráfico de pizza: {str(e)}")

    def grafico_de_barras(self):
        try:
            unique_values, counts = zip(*[(value, self.dado.count(value)) for value in set(self.dado)])
            plt.bar(unique_values, counts, align='center', alpha=0.7)
            plt.xlabel('Dado')
            plt.ylabel('Número de Ocorrências')
            plt.title('Gráfico de Barras')
            plt.show()
        except Exception as e:
            messagebox.showinfo("Aviso", f"Erro ao criar o gráfico de barras: {str(e)}")
        




