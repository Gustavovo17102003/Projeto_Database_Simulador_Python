import interface_de_login
from tkinter import messagebox

class programa:
    #construtor
    def __init__(self):
        self.interfa_inicial = interface_de_login.login()

    #função inicial do programa
    try:
        def run(self):
            self.interfa_inicial.Janela()
    except ValueError:
        messagebox.showinfo("Aviso", "Erro na função run!")
        
app = programa()
app.run()