import tkinter as tk
import banco_de_informacoes
from tkinter import messagebox


class interface_banco:
    #construtor
    def __init__(self):
        self.janela = tk.Tk()
        self.database_informacoes = banco_de_informacoes.BancoInformacoes()

    


    #função da janela
    def Janela(self):

        def Botao_grafico_barras():
            self.database_informacoes.grafico_de_barras()

        def Botao_grafico_pizza():
            try:
                self.database_informacoes.grafico_de_pizza()
                Atualizar()
            except ValueError:
                messagebox.showinfo("Aviso", "Erro no botão do  gráfico de pizza!")

        def Atualizar():
            try:
                if self.database_informacoes is not None:
                    self.texto.delete(1.0, tk.END)
                    tabela_text = str(self.database_informacoes.tabela())
                    self.texto.insert(1.0, tabela_text)
                else:
                    print("Error: self.database_informacoes is not instantiated.")
            except ValueError:
                messagebox.showinfo("Aviso", "Erro na função atualizar!")


        # Função para o botão inserir
        def mine_interface_inserir():
            try:
                def Botao_inserir():
                    try:
                        dado = str(campo_dado.get())
                        self.database_informacoes.inserir(dado)
                        Atualizar()
                    except ValueError:
                        messagebox.showinfo("Aviso", "Erro na função do botão inserir!")

                janela = tk.Tk()
                janela.configure(background="light blue")
                janela.title("")
                janela.geometry("200x70")

                label_dado = tk.Label(janela, text="Dado")
                label_dado.configure(background="light blue")
                label_dado.grid(row=0, column=0, padx=5, pady=5)

                campo_dado = tk.Entry(janela)
                campo_dado.grid(row=0, column=1, padx=5, pady=5)

                botao_inserir = tk.Button(janela, text="Inserir",command=Botao_inserir)
                botao_inserir.grid(row=1, column=0, padx=5, pady=5)

                janela.mainloop()

            except ValueError:
                messagebox.showinfo("Aviso", "Erro na mine interface inserir!")

           

        # Função para o botão remover
        def mine_interface_remover():
            try:
                def Botao_remover():
                    try:
                        dado = str(campo_dado.get())
                        self.database_informacoes.apagar(dado)
                        Atualizar()
                    except ValueError:
                        messagebox.showinfo("Aviso", "Erro na função botão remover!")

                janela = tk.Tk()
                janela.configure(background="light blue")
                janela.title("")
                janela.geometry("200x70")

                label_dado = tk.Label(janela, text="Dado")
                label_dado.configure(background="light blue")
                label_dado.grid(row=0, column=0, padx=5, pady=5)

                campo_dado = tk.Entry(janela)
                campo_dado.grid(row=0, column=1, padx=5, pady=5)

                botao_remover = tk.Button(janela, text="Remover",command=Botao_remover)
                botao_remover.grid(row=1, column=0, padx=5, pady=5)

                janela.mainloop()
                Atualizar()

            except ValueError:
                messagebox.showinfo("Aviso", "Erro na função mine interface remover!")

            
                

        try:
            def Ocorrencia_interface():

                def Botao_verificar():
                    dado = campo_dado.get()
                    self.database_informacoes.Ocorrencias(dado)
                    Atualizar()

                janela_ocorrencias = tk.Tk()
                janela_ocorrencias.configure(background="light blue")
                janela_ocorrencias.title("")
                janela_ocorrencias.geometry("200x70")

                label_dado = tk.Label(janela_ocorrencias,text="Dado")
                label_dado.configure(background="light blue")
                label_dado.grid(row=0,column=0,padx=5,pady=5)

                campo_dado = tk.Entry(janela_ocorrencias)
                campo_dado.grid(row=0,column=1,padx=5,pady=5)

                botao_verificar = tk.Button(janela_ocorrencias,text="Verificar",command=Botao_verificar)
                botao_verificar.grid(row=1,column=0,padx=5,pady=5)

                janela_ocorrencias.mainloop()
                Atualizar()
        except ValueError:
            messagebox.showinfo("Aviso", "Erro na função Botao_criar_usuarios!")

        self.janela.title("Simulador de Banco de Dados")
        self.janela.configure(background="bisque2")
        self.janela.geometry("700x420")

        self.botao_frequencia = tk.Button(self.janela,text="Número de Ocorrência",relief='flat',command=Ocorrencia_interface)
        self.botao_frequencia.config(background="SpringGreen2")
        self.botao_frequencia.place(x=10,y=10,width=150)

        self.botao_grafico_de_barras = tk.Button(self.janela,text="Gráfico de Barras",relief='flat',command=Botao_grafico_barras)
        self.botao_grafico_de_barras.config(background="SpringGreen2")
        self.botao_grafico_de_barras.place(x=10,y=50,width=150)

        self.botao_grafico_de_pizza = tk.Button(self.janela,text="Gráfico de Pizza",relief='flat',command=Botao_grafico_pizza)
        self.botao_grafico_de_pizza.config(background="SpringGreen2")
        self.botao_grafico_de_pizza.place(x=10,y=90,width=150)

        self.botao_inserir = tk.Button(self.janela,text="Inserir Dado",relief='flat',command=mine_interface_inserir)
        self.botao_inserir.config(background="SpringGreen2")
        self.botao_inserir.place(x=10,y=140,width=150)

        self.botao_remover = tk.Button(self.janela,text="Remover Dado",relief='flat',command=mine_interface_remover)
        self.botao_remover.config(background="SpringGreen2")
        self.botao_remover.place(x=10,y=190,width=150)

        self.texto = tk.Text(self.janela,relief='flat')
        self.texto.config(background="sky blue")
        self.texto.place(x=170,y=10,width=520,height=400)
        self.texto.insert("1.0","Banco de dados vazio!")

        self.janela.mainloop()

